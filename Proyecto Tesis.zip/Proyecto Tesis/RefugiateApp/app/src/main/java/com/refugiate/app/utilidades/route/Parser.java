package com.refugiate.app.utilidades.route;
//. by Haseem Saheed
public interface Parser {
    public Route parse();
}