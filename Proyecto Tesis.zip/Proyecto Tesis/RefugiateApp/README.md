Material Design Navigation Drawer. 

*Take care, the name of the folders that contain this project should haven't spaces,
 in my computers I had rendering problems in the preview window caused by this.

Features:

  - Navigation drawer over status bar (Lollipop and Kitkat)
  - Translucent navigation bar (Lollipop and Kitkat)
  - Translucent status bar (Kitkat, gradient)
  - It works perfectly for 4.1+ (portrait and landscape mode).
  - It works perfectly in any device (smartphone or tablet).
  
<a href="https://play.google.com/store/apps/details?id=com.videumcorp.desarrolladorandroid.materialdesignnavigationdrawer">
  <img alt="Get it on Google Play"
       src="https://developer.android.com/images/brand/en_generic_rgb_wo_60.png" />
</a>
